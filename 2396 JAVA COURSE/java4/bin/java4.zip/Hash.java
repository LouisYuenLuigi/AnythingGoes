
public interface Hash {
	String algorithm = "SHA-1";
	String hash(String p);
	String bytesToString(byte[] b);
		

}
