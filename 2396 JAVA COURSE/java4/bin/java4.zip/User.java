
public class User {
	private String username;
	private String hashedPass;
	private String fullname;
	private String email;
	private String phone;
	private Integer failedLogins;
	private boolean accountLocked;
	
	public User() {
		username = new String();
		hashedPass = new String();
		fullname = new String();
		email = new String();
		phone = new String();
		failedLogins = 0;
		accountLocked = false;
	}
	public String getUsername() {
		return this.username;
	}
	public void setUsername(String newname) {
		this.username = newname;
	}
	public String getHashedPass() {
		return this.hashedPass;
	}
	public void setHashedPass(String newpass) {
		this.hashedPass = newpass;
	}
	public String getFullname() {
		return this.fullname;
	}
	public void setFullname(String newname) {
		this.fullname = newname;
	}
	public String getEmail() {
		return this.email;
	}
	public void setEmail(String newemail) {
		this.email = newemail;
	}
	public String getPhone() {
		return this.phone;
	}
	public void setPhone(String newphone) {
		this.phone = newphone;
	}

	public void loginfail() {
		this.failedLogins++;
		if (failedLogins >= 3) {
			this.accountLocked = true;
		}
	}
	public void resetLogins() {
		this.failedLogins = 0;
	}
	public boolean getAccountLocked() {
		return this.accountLocked;
	}

}
