import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.ArrayList;

public class Commands implements Hash {
	private ArrayList<User> users;

	public Commands() {
		users = new ArrayList<User>();
	}
	public void firstmessage() {
		System.out.println("Welcome to the COMP2396 Authentication system!\n1. Authenticate user\n2. Add user record\n3. Edit user record\nWhat would you like to perform?\nPlease enter your command (1-3, or 0 to terminate the system):");
	}
	public ArrayList<User> getUsers(){
		return users;
	}
	public String getUsername(Integer index) {
		return getUsers().get(index).getUsername();
	}
	public boolean usernameTaken(String username) {
		for (int i=0;i<getUsers().size();i++) {
			if (username.contentEquals(getUsername(i))) {
				return true;
			}
			
		}
		return false;
	}
	public String getHashedPass(Integer index) {
		return getUsers().get(index).getHashedPass();
	}
	
	public void addUser(User u) {
		this.users.add(u);
	}
	public void loginFail(User u) {
		u.loginfail();
	}
	public boolean getLocked(User u) {
		return u.getAccountLocked();
	}
	public void resetLogins(User u) {
		u.resetLogins();
	}
	

	public boolean checkPass(String p) {
		if (p.length() >= 6) {
			if (checkfor(p)) {
				return true;
			}
			else {
				
				return false;
			}
			
		}
		else {
			
			return false;
		}
	}
	private String numberList = "1234567890";
	private String upperList = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private String lowerList = "abcdefghijklmnopqrstuvwxyz";
	private boolean checkfor(String pass) {
		boolean hasnum = false;
		boolean hasup = false;
		boolean haslow = false;
		char ind;
		for (int i=0;i<pass.length();i++) {
			ind = pass.charAt(i);
			if (numberList.indexOf(ind) != -1) {
				hasnum = true;
			}
			else if(upperList.indexOf(ind) != -1) {
				hasup = true;
			}
			else if(lowerList.indexOf(ind) != -1) {
				haslow = true;
			}
			if (hasnum && hasup && haslow) {
				return true;
			}
		}
		return false;
	}
	public String readInput() {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String inputLine = "";
		try {
		inputLine = input.readLine();
		}
		catch (IOException e) {
		System.out.print("Input Error.");
		}
		return inputLine;
	}
	
	public String hash(String message) {
		try {
			MessageDigest p = MessageDigest.getInstance(algorithm);
			p.update(message.getBytes());
			byte[] hash = p.digest();

			return bytesToString(hash);

		}
		catch(Exception e) {	
		}
		return "Error";
	}
	private final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();	
	public String bytesToString(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for (int j = 0; j < bytes.length; j++) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = HEX_ARRAY[v >>> 4];
	        hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
	    }
	    return new String(hexChars);
	    
	}

}
