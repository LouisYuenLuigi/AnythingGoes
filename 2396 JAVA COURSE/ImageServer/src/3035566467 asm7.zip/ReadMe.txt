First, run the ImageServer, select an image, then select the user.txt.
Then run the ImagePeers, input the ip, the username, and the password to start image sharing. The account locks after 3 failed logins.

The main.java from assignment 4 is included in case you want to generate new user.txt login databases. 