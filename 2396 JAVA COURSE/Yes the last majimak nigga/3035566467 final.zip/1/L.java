
public class L {
	
	private LL h;
	
	public L() {
		h = null;
	}
	
	public L(LL ll) {
		h = ll;
	}
	
	public void R() {
		
		LL l1, l2, l3, l4;
		
		if ( h== null ) return;
		
		l1 = null;
		l2 = h;
		l3 = null;
		
		while ( l2 != null ) {
			l3 = l2.n;
			l2.n = l1;
			l1 = l2;
			l2 = l3;
			
		}
		
		h = l1;
	}
	
	public void printL() {
		LL l = h;
		
		while ( l != null ) {
			System.out.println(l.getV());;
			l = l.n;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Start L");
		
		LL ll = new LL(1,new LL(2, new LL(3, new LL(4))));
		L l = new L(ll);
		
		l.printL();
		l.R();
		System.out.println("After R");
		l.printL();		
		

	}

}
