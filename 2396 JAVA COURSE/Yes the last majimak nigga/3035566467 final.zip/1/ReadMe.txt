For IsLY and EN, before running, go to run configurations and input the program argument into the arguments box.

IsLY determines whether the year is a leap year.
EN gives out the english form of a number.
L reverses a linked list.